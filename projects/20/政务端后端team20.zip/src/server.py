import json
import os
import time
import requests

from flask import Flask, render_template
from flask import request
from flask_cors import cross_origin
from werkzeug.utils import redirect

app = Flask(__name__)


@app.route('/upload-data',methods=['GET','POST'])
@cross_origin()
def upload_data():
    file_path = os.path.dirname(os.path.realpath(__file__))+'/data.json'
    with open(file_path,'r') as load_data:
        payload = json.load(load_data)
    print(len(payload))
    print(type(payload[0]))
    headers = {'Content-Type': 'application/json'}


    return 'test'


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8081)