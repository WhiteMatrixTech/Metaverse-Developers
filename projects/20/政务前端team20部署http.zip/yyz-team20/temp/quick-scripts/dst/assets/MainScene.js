
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/MainScene.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'fcd4eku5ZdI1blhVS701cye', 'MainScene');
// MainScene.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    toastNode: cc.Node
  },
  start: function start() {},
  onClick: function onClick() {
    var xhr = new XMLHttpRequest();

    xhr.onreadystatechange = function () {
      if (xhr.readyState == 4 && xhr.status >= 200 && xhr.status < 400) {
        console.log('onreadystatechange', xhr);
      }
    };

    xhr.onerror = function () {
      console.log('onerror');
    };

    xhr.open('GET', 'http://139.9.117.156:8081/test');
    xhr.responseType = 'text';
    xhr.send(null);
    this.toastNode.stopAllActions();
    this.toastNode.opacity = 0;
    this.toastNode.runAction(cc.sequence(cc.fadeIn(0.2), cc.delayTime(0.5), cc.fadeOut(0.2)));
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0cy9NYWluU2NlbmUuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJ0b2FzdE5vZGUiLCJOb2RlIiwic3RhcnQiLCJvbkNsaWNrIiwieGhyIiwiWE1MSHR0cFJlcXVlc3QiLCJvbnJlYWR5c3RhdGVjaGFuZ2UiLCJyZWFkeVN0YXRlIiwic3RhdHVzIiwiY29uc29sZSIsImxvZyIsIm9uZXJyb3IiLCJvcGVuIiwicmVzcG9uc2VUeXBlIiwic2VuZCIsInN0b3BBbGxBY3Rpb25zIiwib3BhY2l0eSIsInJ1bkFjdGlvbiIsInNlcXVlbmNlIiwiZmFkZUluIiwiZGVsYXlUaW1lIiwiZmFkZU91dCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQUEsRUFBRSxDQUFDQyxLQUFILENBQVM7QUFDTCxhQUFTRCxFQUFFLENBQUNFLFNBRFA7QUFHTEMsRUFBQUEsVUFBVSxFQUFFO0FBQ1JDLElBQUFBLFNBQVMsRUFBRUosRUFBRSxDQUFDSztBQUROLEdBSFA7QUFPTEMsRUFBQUEsS0FQSyxtQkFPRyxDQUVQLENBVEk7QUFXTEMsRUFBQUEsT0FYSyxxQkFXSztBQUVOLFFBQUlDLEdBQUcsR0FBRyxJQUFJQyxjQUFKLEVBQVY7O0FBQ0FELElBQUFBLEdBQUcsQ0FBQ0Usa0JBQUosR0FBeUIsWUFBWTtBQUNqQyxVQUFJRixHQUFHLENBQUNHLFVBQUosSUFBa0IsQ0FBbEIsSUFBdUJILEdBQUcsQ0FBQ0ksTUFBSixJQUFjLEdBQXJDLElBQTRDSixHQUFHLENBQUNJLE1BQUosR0FBYSxHQUE3RCxFQUFrRTtBQUM5REMsUUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksb0JBQVosRUFBa0NOLEdBQWxDO0FBQ0g7QUFDSixLQUpEOztBQUtBQSxJQUFBQSxHQUFHLENBQUNPLE9BQUosR0FBYyxZQUFZO0FBQ3RCRixNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxTQUFaO0FBQ0gsS0FGRDs7QUFHQU4sSUFBQUEsR0FBRyxDQUFDUSxJQUFKLENBQVMsS0FBVCxFQUFnQixnQ0FBaEI7QUFDQVIsSUFBQUEsR0FBRyxDQUFDUyxZQUFKLEdBQW1CLE1BQW5CO0FBQ0FULElBQUFBLEdBQUcsQ0FBQ1UsSUFBSixDQUFTLElBQVQ7QUFFQSxTQUFLZCxTQUFMLENBQWVlLGNBQWY7QUFDQSxTQUFLZixTQUFMLENBQWVnQixPQUFmLEdBQXlCLENBQXpCO0FBQ0EsU0FBS2hCLFNBQUwsQ0FBZWlCLFNBQWYsQ0FBeUJyQixFQUFFLENBQUNzQixRQUFILENBQ3JCdEIsRUFBRSxDQUFDdUIsTUFBSCxDQUFVLEdBQVYsQ0FEcUIsRUFFckJ2QixFQUFFLENBQUN3QixTQUFILENBQWEsR0FBYixDQUZxQixFQUdyQnhCLEVBQUUsQ0FBQ3lCLE9BQUgsQ0FBVyxHQUFYLENBSHFCLENBQXpCO0FBS0gsR0FqQ0ksQ0FtQ0w7O0FBbkNLLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIExlYXJuIGNjLkNsYXNzOlxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvY2xhc3MuaHRtbFxuLy8gTGVhcm4gQXR0cmlidXRlOlxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvcmVmZXJlbmNlL2F0dHJpYnV0ZXMuaHRtbFxuLy8gTGVhcm4gbGlmZS1jeWNsZSBjYWxsYmFja3M6XG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9saWZlLWN5Y2xlLWNhbGxiYWNrcy5odG1sXG5cbmNjLkNsYXNzKHtcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXG5cbiAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgIHRvYXN0Tm9kZTogY2MuTm9kZSxcbiAgICB9LFxuXG4gICAgc3RhcnQoKSB7XG5cbiAgICB9LFxuXG4gICAgb25DbGljaygpIHtcblxuICAgICAgICB2YXIgeGhyID0gbmV3IFhNTEh0dHBSZXF1ZXN0KCk7XG4gICAgICAgIHhoci5vbnJlYWR5c3RhdGVjaGFuZ2UgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBpZiAoeGhyLnJlYWR5U3RhdGUgPT0gNCAmJiB4aHIuc3RhdHVzID49IDIwMCAmJiB4aHIuc3RhdHVzIDwgNDAwKSB7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coJ29ucmVhZHlzdGF0ZWNoYW5nZScsIHhocik7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgeGhyLm9uZXJyb3IgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZygnb25lcnJvcicpO1xuICAgICAgICB9XG4gICAgICAgIHhoci5vcGVuKCdHRVQnLCAnaHR0cDovLzEzOS45LjExNy4xNTY6ODA4MS90ZXN0Jyk7XG4gICAgICAgIHhoci5yZXNwb25zZVR5cGUgPSAndGV4dCc7XG4gICAgICAgIHhoci5zZW5kKG51bGwpXG5cbiAgICAgICAgdGhpcy50b2FzdE5vZGUuc3RvcEFsbEFjdGlvbnMoKTtcbiAgICAgICAgdGhpcy50b2FzdE5vZGUub3BhY2l0eSA9IDA7XG4gICAgICAgIHRoaXMudG9hc3ROb2RlLnJ1bkFjdGlvbihjYy5zZXF1ZW5jZShcbiAgICAgICAgICAgIGNjLmZhZGVJbigwLjIpLFxuICAgICAgICAgICAgY2MuZGVsYXlUaW1lKDAuNSksXG4gICAgICAgICAgICBjYy5mYWRlT3V0KDAuMiksXG4gICAgICAgICkpXG4gICAgfSxcblxuICAgIC8vIHVwZGF0ZSAoZHQpIHt9LFxufSk7XG4iXX0=