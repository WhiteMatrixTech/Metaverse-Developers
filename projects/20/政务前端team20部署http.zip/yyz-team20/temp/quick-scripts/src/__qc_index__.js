
require('./assets/MainScene');
