// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html

cc.Class({
    extends: cc.Component,

    properties: {
        toastNode: cc.Node,
    },

    start() {

    },

    onClick() {

        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function () {
            if (xhr.readyState == 4 && xhr.status >= 200 && xhr.status < 400) {
                console.log('onreadystatechange', xhr);
            }
        }
        xhr.onerror = function () {
            console.log('onerror');
        }
        xhr.open('GET', 'http://139.9.117.156:8081/test');
        xhr.responseType = 'text';
        xhr.send(null)

        this.toastNode.stopAllActions();
        this.toastNode.opacity = 0;
        this.toastNode.runAction(cc.sequence(
            cc.fadeIn(0.2),
            cc.delayTime(0.5),
            cc.fadeOut(0.2),
        ))
    },

    // update (dt) {},
});
